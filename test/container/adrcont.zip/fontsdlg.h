#define ID_FontsDlg                 600
#define ID_FontsCombo               601
#define ID_Fonts8                   602
#define ID_Fonts10                  603
#define ID_FontsOkay                604
#define ID_FontsCancel              605
#define ID_Fonts9                   606
#define ID_FontTest                 607
