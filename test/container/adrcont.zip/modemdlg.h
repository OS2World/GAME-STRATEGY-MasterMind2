#define ID_ModemDialog              400
#define ID_ModemCommP               401
#define ID_ModemBaudR               402
#define ID_ModemPTWahl              403
#define ID_ModemOK                  404
#define ID_ModemCancel              405
