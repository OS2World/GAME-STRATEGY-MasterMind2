/* leere Datei zur erstellugn der Ressource DLLs */
